# @firebase/app-check-interop-types

## 0.1.0
### Minor Changes



- [`81c131abe`](https://github.com/firebase/firebase-js-sdk/commit/81c131abea7001c5933156ff6b0f3925f16ff052) [#4860](https://github.com/firebase/firebase-js-sdk/pull/4860)  - Release the Firebase App Check package.
