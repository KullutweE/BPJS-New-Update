var parent = require('../../es/array-buffer/is-view');

module.exports = parent;
