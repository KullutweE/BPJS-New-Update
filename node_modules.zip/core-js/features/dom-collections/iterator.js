var parent = require('../../stable/dom-collections/iterator');

module.exports = parent;
