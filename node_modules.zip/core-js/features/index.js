var parent = require('..');

module.exports = parent;
