var parent = require('../../es/json/to-string-tag');

module.exports = parent;
