var parent = require('../../es/instance/trim-end');

module.exports = parent;
