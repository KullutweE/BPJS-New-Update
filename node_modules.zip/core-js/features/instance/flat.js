var parent = require('../../es/instance/flat');

module.exports = parent;
