var parent = require('../../es/instance/find-index');

module.exports = parent;
