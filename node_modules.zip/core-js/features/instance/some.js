var parent = require('../../es/instance/some');

module.exports = parent;
