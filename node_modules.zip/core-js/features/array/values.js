var parent = require('../../es/array/values');

module.exports = parent;
