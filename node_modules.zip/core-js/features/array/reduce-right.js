var parent = require('../../es/array/reduce-right');

module.exports = parent;
