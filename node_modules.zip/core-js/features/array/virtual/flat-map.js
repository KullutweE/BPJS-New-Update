var parent = require('../../../es/array/virtual/flat-map');

module.exports = parent;
