var parent = require('../../../es/array/virtual');

module.exports = parent;
