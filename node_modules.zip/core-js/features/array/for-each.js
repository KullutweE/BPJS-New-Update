var parent = require('../../es/array/for-each');

module.exports = parent;
