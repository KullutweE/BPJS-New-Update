require('../modules/esnext.composite-key');
var path = require('../internals/path');

module.exports = path.compositeKey;
